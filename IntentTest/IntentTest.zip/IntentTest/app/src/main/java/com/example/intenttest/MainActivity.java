package com.example.intenttest;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout1);

        Button b = (Button)findViewById(R.id.Button01);
        final String text = b.getText().toString();
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Activity2.class);
                intent.putExtra("BtnText", text);  //이벤트처리객체 안에서 외부에 있는 인스턴스를 호출할 때 개체의 값이 변하면 안되기 때문에 final로 선언해준다.
                startActivity(intent);
            }
        });
    }
}
