package com.example.intenttest;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Activity2 extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout2);

        TextView textView = findViewById(R.id.tvActivity2);
        Intent intent = getIntent();
        textView.setText(intent.getStringExtra("BtnText"));
        Button b = (Button)findViewById(R.id.Button02);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); //Activity2 화면이 닫힘.
            }
        });
    }
}
