package com.example.m2015041063;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    String NOTIFICATION_CHANNEL_ID = "my_channel_id_01";

    Button btnReservation;
    TimePickerDialog timePickerDialog;
    TextView result;
    View count = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnReservation = findViewById(R.id.btnReserv);
        result = findViewById(R.id.reservTime);
        createNotificationChannel();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.reservation, menu);
        final MenuItem menuItem = menu.findItem(R.id.action_send);
        count = menu.findItem(R.id.action_send).getActionView();
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()) {
            case R.id.action_send:
                sendNotification(count);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void createNotificationChannel()    {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)  {
            NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID,
                    "My Notification", NotificationManager.IMPORTANCE_DEFAULT);
            notificationChannel.setDescription("Channel description");
            NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    public void sendNotification(View v)    {
        //builder를 생성(몇 번째 채널에 해당하는 것이다 라고 명시)
        NotificationCompat.Builder notificationBuilder = new NotificationCompat.Builder(
                this, NOTIFICATION_CHANNEL_ID);
        //기능

        //notification의 내용물
        notificationBuilder.setSmallIcon(R.drawable.ic_launcher_foreground).
                setContentTitle("예약알림")
                .setContentText(result.getText() + " 예약되었습니다.");
        //Notification를 관리한다.(시스템으로부터 얻어와야 한다.)
        NotificationManager notificationManager = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        //notificationBuilder.build 알림개최자(알림객체)
        notificationManager.notify(1, notificationBuilder.build());
    }

    public void onClick(View v) {
        if (v == btnReservation) {
            Calendar c = Calendar.getInstance();
            int mHour = c.get(Calendar.HOUR_OF_DAY);
            int mMinute = c.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(this,
                    new TimePickerDialog.OnTimeSetListener() {
                        @Override
                        public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                            result.setText(hourOfDay + "시" + minute + "분");
                        }
                    }, mHour, mMinute, false);
            timePickerDialog.show();
        }
    }
}
